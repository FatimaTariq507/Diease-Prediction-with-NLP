import numpy as np
import pickle
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

# Load data
X_val = np.load("X.npy")
y_val = np.load("y.npy")

# Load models
rf = pickle.load(open("models/rf_model.pkl", "rb"))
nb = pickle.load(open("models/nb_model.pkl", "rb"))
lr = pickle.load(open("models/lr_model.pkl", "rb"))

# Accuracy
acc_rf = accuracy_score(y_val, rf.predict(X_val))
acc_nb = accuracy_score(y_val, nb.predict(X_val))
acc_lr = accuracy_score(y_val, lr.predict(X_val))

# Plot
models = ['Random Forest', 'Naive Bayes', 'Logistic Regression']
accuracies = [acc_rf, acc_nb, acc_lr]

plt.figure(figsize=(8,5))
plt.bar(models, accuracies, color=['skyblue', 'lightgreen', 'salmon'])
plt.title("Model Accuracy Comparison")
plt.ylabel("Accuracy")
plt.ylim(0, 1)
plt.grid(axis='y')
plt.show()
