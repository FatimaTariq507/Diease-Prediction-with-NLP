import numpy as np
import pickle
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression

# Load data
X_train = np.load("X.npy")
y_train = np.load("y.npy")

# Ensure models directory
os.makedirs("models", exist_ok=True)

# Train models
rf = RandomForestClassifier()
rf.fit(X_train, y_train)
pickle.dump(rf, open("models/rf_model.pkl", "wb"))

nb = GaussianNB()
nb.fit(X_train, y_train)
pickle.dump(nb, open("models/nb_model.pkl", "wb"))

lr = LogisticRegression(max_iter=1000)
lr.fit(X_train, y_train)
pickle.dump(lr, open("models/lr_model.pkl", "wb"))

print("✅ All models trained and saved.")
