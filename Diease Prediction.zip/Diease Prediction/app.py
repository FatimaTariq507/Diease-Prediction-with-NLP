import streamlit as st
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

st.title("🧠 Disease Prediction from Symptoms")

# Load model
model = pickle.load(open("models/rf_model.pkl", "rb"))

# Load data and setup
df = pd.read_csv("cleaned_data.csv")
all_symptoms = df.drop("prognosis", axis=1).columns.tolist()

# Fit label encoder
label_encoder = LabelEncoder()
label_encoder.fit(df['prognosis'])

# 🔤 Text input for manual entry
st.markdown("### ✍️ Type Symptoms (Optional)")
typed_symptom1 = st.text_input("Symptom 1")
typed_symptom2 = st.text_input("Symptom 2")
typed_symptom3 = st.text_input("Symptom 3")

# 🔽 Dropdown multiselect
st.markdown("### 🔽 Or Choose from List")
selected_symptoms = st.multiselect("Select additional symptoms", sorted(all_symptoms))

# 👉 Combine all symptoms (typed + selected)
typed_inputs = [typed_symptom1.strip().lower(), typed_symptom2.strip().lower(), typed_symptom3.strip().lower()]
typed_valid = [s for s in typed_inputs if s in [x.lower() for x in all_symptoms]]

# Convert lower-case to original symptom name from list
typed_final = [sym for sym in all_symptoms if sym.lower() in typed_valid]

# Combine unique symptoms
final_symptoms = list(set(typed_final + selected_symptoms))

if st.button("Predict"):

    if not final_symptoms:
        st.error("❌ Please type or select at least one valid symptom.")
    else:
        input_data = [1 if symptom in final_symptoms else 0 for symptom in all_symptoms]
        input_array = np.array(input_data).reshape(1, -1)

        # Get top 3 predictions
        probs = model.predict_proba(input_array)[0]
        top_3_indices = np.argsort(probs)[::-1][:3]

        st.subheader("🔍 Top 3 Predicted Diseases:")
        for idx in top_3_indices:
            disease = label_encoder.inverse_transform([idx])[0]
            confidence = probs[idx] * 100
            st.write(f"👉 **{disease}** — Confidence: **{confidence:.2f}%**")
