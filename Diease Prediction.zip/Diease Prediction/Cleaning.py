import pandas as pd

# Step 1: Load original training data
df = pd.read_csv("Training.csv")

# Step 2: Extra column 'Unnamed: 133' hata do (yeh khali column hai)
if 'Unnamed: 133' in df.columns:
    df = df.drop(columns=['Unnamed: 133'])

# Step 3: Check how many missing values
print("Missing values before cleaning:\n", df.isnull().sum())

# Step 4: (Optional) Only remove rows with all columns missing
df = df.dropna(how='all')

# Step 5: Duplicates remove karo
df = df.drop_duplicates()

# Step 6: Save cleaned data
df.to_csv("cleaned_data.csv", index=False)
print(f"✅ Cleaned data saved with {df.shape[0]} rows and {df.shape[1]} columns.")
