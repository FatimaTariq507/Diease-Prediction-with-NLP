import numpy as np
import pickle
from sklearn.metrics import accuracy_score

# Load test data
X_test = np.load("X.npy")
y_test = np.load("y.npy")

# Load models
rf = pickle.load(open("models/rf_model.pkl", "rb"))
nb = pickle.load(open("models/nb_model.pkl", "rb"))
lr = pickle.load(open("models/lr_model.pkl", "rb"))

# Evaluate
print("Random Forest Accuracy:", accuracy_score(y_test, rf.predict(X_test)))
print("Naive Bayes Accuracy:", accuracy_score(y_test, nb.predict(X_test)))
print("Logistic Regression Accuracy:", accuracy_score(y_test, lr.predict(X_test)))
