import pandas as pd
from sklearn.preprocessing import LabelEncoder

# Data load karo
df = pd.read_csv("cleaned_data.csv")

# Disease column encode karo
label_encoder = LabelEncoder()
df['prognosis'] = label_encoder.fit_transform(df['prognosis'])


# Features aur labels split karo
X = df.drop("prognosis", axis=1)
y = df["prognosis"]

# Save karo numpy arrays
import numpy as np
np.save("X.npy", X)
np.save("y.npy", y)


print(X.shape)
print(y.shape)

if X.shape[0] == 0 or y.shape[0] == 0:
    print("⚠️ X ya y empty hai! Check cleaned_data.csv file.")
else:
    print("✅ Preprocessing done successfully.")

